import pandas as pd
df = pd.read_csv ('hospitallist.csv')


#df["indeed_job_link"] = "https://www.indeed.com/q-" + df["Name"] + "-jobs.html"
#df.to_csv("hospitalresultindeed.csv", index=False)


#df["linkedin_job_link"] = "https://www.linkedin.com/jobs/search/?f_LF=f_AL&keywords=" + df["Name"] + "&location=United%20States"
#df.to_csv("hospitalresultlinkedineasyapply.csv", index=False)


#df["linkedin_job_link"] = "https://www.linkedin.com/jobs/search/?keywords=" + df["Name"] + "&location=United%20States"
#df.to_csv("hospitalresultlinkedin.csv", index=False)


#df["biospace_job_link"] = "https://www.biospace.com/searchjobs/?Keywords=" + df["Name"]
#df.to_csv("hospitalresultbiospace.csv", index=False)
