import requests 
from bs4 import BeautifulSoup 
import csv
URL = "https://people.rit.edu/~gtfsbi/Symp/microbiology.htm"
r = requests.get(URL)
soup = BeautifulSoup(r.content, 'html5lib')
#with open('collegelist.csv', 'a') as file:
#    writer = csv.writer(file)
for link in soup.findAll():
    print(link.get_text())
#    		writer.writerow([link.find('a').text.encode('utf-8')])

