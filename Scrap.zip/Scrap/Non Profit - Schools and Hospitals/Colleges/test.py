import csv
filename = 'hospitallist.csv'
with open(filename, 'wb') as f: 
    w = csv.DictWriter(f,['url','company']) 
    w.writeheader() 
    for quote in quotes: 
        w.writerow(quote) 
