import requests 
from bs4 import BeautifulSoup 
import csv
URL = "https://curlie.org/en/Health/Medicine/Facilities/Hospitals/North_America/United_States/Wyoming"
r = requests.get(URL)
soup = BeautifulSoup(r.content, 'html5lib')
with open('hospitallist.csv', 'a') as file:
    writer = csv.writer(file)
    for link in soup.findAll('div',{"class":"site-title"}):
    		writer.writerow([link.find('a').text.encode('utf-8')])

