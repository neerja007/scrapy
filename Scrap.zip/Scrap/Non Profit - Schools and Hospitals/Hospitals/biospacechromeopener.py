import webbrowser
import csv
import pandas as pd
df = pd.read_csv("hospitalresultbiospace.csv")
for i in range(len(df)) : 
  if i%25==0 : raw_input("continue?")
  #print(df.loc[i, "biospace_job_link"])
  webbrowser.get('chromium-browser').open_new_tab(df.loc[i,"biospace_job_link"])
