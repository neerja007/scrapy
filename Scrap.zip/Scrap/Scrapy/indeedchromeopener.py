import webbrowser
import csv
import pandas as pd
df = pd.read_csv("resultindeed.csv")
#a_website = df['indeed_job_link']
for i in range(len(df)) : 
  if i%25==0 : raw_input("continue?")
  #print(df.loc[i, "indeed_job_link"]) 
  webbrowser.get('chromium-browser').open_new_tab(df.loc[i, "indeed_job_link"])

