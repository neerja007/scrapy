import pandas as pd
df = pd.read_csv ('exhautivecompanynames.csv')


#df["indeed_job_link"] = "https://www.indeed.com/cmp/" + df["Company"] + "/jobs"
#df.to_csv("resultindeed.csv", index=False)


#df["linkedin_job_link"] = "https://www.linkedin.com/jobs/search/?f_LF=f_AL&keywords=" + df["Company"] + "&location=United%20States"
#df.to_csv("resultlinkedineasyapply.csv", index=False)


#df["linkedin_job_link"] = "https://www.linkedin.com/jobs/search/?keywords=" + df["Company"] + "&location=United%20States"
#df.to_csv("resultlinkedin.csv", index=False)


#df["biospace_job_link"] = "https://www.biospace.com/searchjobs/?Keywords=" + df["Company"]
#df.to_csv("resultbiospace.csv", index=False)
