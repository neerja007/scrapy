import requests 
from bs4 import BeautifulSoup 
import csv
URL = "https://biopharmguy.com/links/company-by-location-singapore.php" #ENTER URL HERE
r = requests.get(URL)
soup = BeautifulSoup(r.content, 'html5lib')
with open('SingaporeCompanies.csv', 'a') as file:
	writer = csv.writer(file)
	for link in soup.find_all(onclick=True):
		writer.writerow([link.get_text().encode('utf-8'), link.get('href').encode('utf-8')])
    		
